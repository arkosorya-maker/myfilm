import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

type Language = 'ku' | 'ar' | 'en';

interface AppState {
  language: Language;
  setLanguage: (lang: Language) => void;
  isSearchOpen: boolean;
  setSearchOpen: (open: boolean) => void;
  isMenuOpen: boolean;
  setMenuOpen: (open: boolean) => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      language: 'ku',
      setLanguage: (lang) => set({ language: lang }),
      isSearchOpen: false,
      setSearchOpen: (open) => set({ isSearchOpen: open }),
      isMenuOpen: false,
      setMenuOpen: (open) => set({ isMenuOpen: open }),
    }),
    {
      name: 'my-film-storage',
      storage: createJSONStorage(() => typeof window !== 'undefined' ? window.localStorage : {
        getItem: () => null,
        setItem: () => {},
        removeItem: () => {},
      }),
      partialize: (state) => ({ language: state.language }),
    }
  )
);
