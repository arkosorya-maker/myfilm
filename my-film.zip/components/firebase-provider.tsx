"use client";

import { createContext, useContext, useEffect, useState } from "react";
import { User, onAuthStateChanged } from "firebase/auth";
import { auth, db } from "@/lib/firebase";
import { doc, getDoc } from "firebase/firestore";

interface AuthContextType {
  user: User | null;
  isAdmin: boolean;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  isAdmin: false,
  loading: true,
});

export function FirebaseProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setUser(user);
      if (user) {
        try {
          const docRef = doc(db, "users", user.uid);
          const docSnap = await getDoc(docRef);
          if (docSnap.exists()) {
            const role = docSnap.data().role;
            const isUserAdmin = role === "admin" || user.email?.toLowerCase() === "arkosorya@gmail.com";
            console.log("User doc exists. Role:", role, "IsAdmin:", isUserAdmin);
            setIsAdmin(isUserAdmin);
          } else {
            const isUserAdmin = user.email?.toLowerCase() === "arkosorya@gmail.com";
            console.log("User doc does not exist. IsAdmin:", isUserAdmin);
            setIsAdmin(isUserAdmin);
          }
        } catch (error) {
          console.error("Error fetching user role:", error);
          // Fallback check just in case firestore fails
          setIsAdmin(user.email?.toLowerCase() === "arkosorya@gmail.com");
        }
      } else {
        setIsAdmin(false);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  return (
    <AuthContext.Provider value={{ user, isAdmin, loading }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
