import Link from "next/link";
import { ChevronLeft } from "lucide-react";
import { ContentCard } from "./content-card";

interface ContentSectionProps {
  title: string;
  items: any[];
  type: "movie" | "series" | "anime" | "channel";
  viewAllLink: string;
}

export function ContentSection({
  title,
  items,
  type,
  viewAllLink,
}: ContentSectionProps) {
  return (
    <section className="py-8 md:py-12">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="flex items-center justify-between mb-6 md:mb-8">
          <h2 className="text-2xl md:text-3xl font-bold text-white tracking-tight">
            {title}
          </h2>
          <Link
            href={viewAllLink}
            className="hidden md:flex items-center gap-1 text-[#8A8FA8] hover:text-white transition-colors text-sm font-medium"
          >
            بینینی هەمووی
            <ChevronLeft className="w-4 h-4" />
          </Link>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">
          {items.map((item) => (
            <ContentCard
              key={item.id}
              id={item.id}
              title={item.title}
              image={item.image}
              views={item.views}
              tags={item.tags}
              type={type}
            />
          ))}
        </div>

        {/* Mobile View All Button */}
        <div className="mt-8 flex justify-center md:hidden">
          <Link
            href={viewAllLink}
            className="bg-[#1A1D27] text-white px-6 py-2.5 rounded-full text-sm font-medium hover:bg-[#2A2D3A] transition-colors shadow-lg"
          >
            بینینی زیاتر...
          </Link>
        </div>
      </div>
    </section>
  );
}
