"use client";

import * as React from "react";
import useEmblaCarousel from "embla-carousel-react";
import Image from "next/image";
import Link from "next/link";
import { motion } from "motion/react";
import { Logo } from "./logo";

const slides = [
  {
    id: "1",
    title: "فیلمی ئاکشن و سەرکێشی",
    image: "https://picsum.photos/seed/hero1/800/1200",
    year: "2024",
    type: "movie",
  },
  {
    id: "2",
    title: "زنجیرەی درامای نوێ",
    image: "https://picsum.photos/seed/hero2/800/1200",
    year: "2023",
    type: "series",
  },
  {
    id: "3",
    title: "ئەنیمەی خەیاڵی",
    image: "https://picsum.photos/seed/hero3/800/1200",
    year: "2024",
    type: "anime",
  },
  {
    id: "4",
    title: "کۆمیدیای خێزانی",
    image: "https://picsum.photos/seed/hero4/800/1200",
    year: "2022",
    type: "movie",
  },
];

export function FeaturedSlider() {
  const [emblaRef, emblaApi] = useEmblaCarousel({
    loop: true,
    align: "start",
    direction: "rtl",
  });
  const [selectedIndex, setSelectedIndex] = React.useState(0);

  React.useEffect(() => {
    if (!emblaApi) return;

    const onSelect = () => {
      setSelectedIndex(emblaApi.selectedScrollSnap());
    };

    emblaApi.on("select", onSelect);
    onSelect();

    return () => {
      emblaApi.off("select", onSelect);
    };
  }, [emblaApi]);

  return (
    <div className="relative w-full overflow-hidden py-6">
      <div className="embla" ref={emblaRef}>
        <div className="embla__container flex touch-pan-y">
          {slides.map((slide, index) => (
            <div
              key={slide.id}
              className="embla__slide flex-[0_0_85%] min-w-0 sm:flex-[0_0_45%] md:flex-[0_0_40%] lg:flex-[0_0_30%] pl-4"
            >
              <Link href={`/${slide.type}/${slide.id}`}>
                <motion.div
                  whileHover={{ scale: 1.02 }}
                  transition={{ duration: 0.2 }}
                  className="relative aspect-[2/3] w-full rounded-2xl overflow-hidden shadow-2xl group cursor-pointer"
                >
                  <Image
                    src={slide.image}
                    alt={slide.title}
                    fill
                    className="object-cover transition-transform duration-500 group-hover:scale-105"
                    sizes="(max-width: 640px) 85vw, (max-width: 1024px) 45vw, 30vw"
                    priority={index < 2}
                  />
                  
                  {/* Gradient Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0A0C12] via-[#0A0C12]/40 to-transparent opacity-90" />

                  {/* Content */}
                  <div className="absolute inset-0 p-4 md:p-6 flex flex-col justify-between">
                    {/* Top Right - Watermark */}
                    <div className="self-end opacity-50 mix-blend-overlay">
                      <Logo className="w-12 h-12 md:w-16 md:h-16" />
                    </div>

                    {/* Bottom Info */}
                    <div className="flex flex-col gap-2">
                      <h2 className="text-white font-bold text-xl md:text-2xl lg:text-3xl leading-tight text-right drop-shadow-lg">
                        {slide.title}
                      </h2>
                      <div className="self-end bg-[#E31C25] text-white text-xs md:text-sm font-bold px-3 py-1 rounded-full shadow-lg">
                        {slide.year}
                      </div>
                    </div>
                  </div>
                </motion.div>
              </Link>
            </div>
          ))}
        </div>
      </div>

      {/* Dots */}
      <div className="flex justify-center gap-2 mt-6">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => emblaApi?.scrollTo(index)}
            className={`w-2 h-2 rounded-full transition-all duration-300 ${
              index === selectedIndex
                ? "bg-[#E31C25] w-6"
                : "bg-[#2A2D3A] hover:bg-[#8A8FA8]"
            }`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>
    </div>
  );
}
