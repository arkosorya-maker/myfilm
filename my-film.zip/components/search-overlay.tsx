"use client";

import { motion, AnimatePresence } from "motion/react";
import { X, Search as SearchIcon, Clock, Loader2 } from "lucide-react";
import { useAppStore } from "@/store/use-app-store";
import { useState, useEffect } from "react";
import { ContentCard } from "./content-card";
import { collection, query, getDocs, orderBy, limit } from "firebase/firestore";
import { db } from "@/lib/firebase";

const categories = [
  { id: "all", label: "هەموو", icon: "🔍" },
  { id: "movie", label: "فیلم", icon: "🎬" },
  { id: "series", label: "زنجیرە", icon: "📺" },
  { id: "anime", label: "ئەنیمە", icon: "🎌" },
  { id: "channel", label: "کەناڵ", icon: "📡" },
];

export function SearchOverlay() {
  const isOpen = useAppStore((state) => state.isSearchOpen);
  const setOpen = useAppStore((state) => state.setSearchOpen);
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);

  // Load recent searches from local storage
  useEffect(() => {
    const stored = localStorage.getItem("recentSearches");
    if (stored) {
      try {
        setRecentSearches(JSON.parse(stored));
      } catch (e) {
        console.error("Failed to parse recent searches");
      }
    }
  }, []);

  useEffect(() => {
    const performSearch = async () => {
      setLoading(true);
      try {
        // In a real app with large datasets, you'd use Algolia or Typesense.
        // For this demo, we'll fetch recent content and filter client-side,
        // or if the dataset is small enough, fetch all and filter.
        // To be more efficient, we could fetch by type if a specific category is selected.
        
        const q = query(collection(db, "content"), orderBy("createdAt", "desc"), limit(100));
        const snapshot = await getDocs(q);
        
        let data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
        
        // Filter by category
        if (selectedCategory !== "all") {
          data = data.filter(item => item.type === selectedCategory);
        }
        
        // Filter by search query (case-insensitive)
        const queryLower = searchQuery.toLowerCase();
        data = data.filter(item => 
          (item.title && item.title.toLowerCase().includes(queryLower)) ||
          (item.originalTitle && item.originalTitle.toLowerCase().includes(queryLower)) ||
          (item.tags && item.tags.some((tag: string) => tag.toLowerCase().includes(queryLower)))
        );
        
        setResults(data);

        // Save to recent searches
        if (searchQuery.trim().length > 2) {
          const newRecent = [searchQuery.trim(), ...recentSearches.filter(s => s !== searchQuery.trim())].slice(0, 5);
          setRecentSearches(newRecent);
          localStorage.setItem("recentSearches", JSON.stringify(newRecent));
        }

      } catch (error) {
        console.error("Error searching:", error);
      } finally {
        setLoading(false);
      }
    };

    if (!searchQuery.trim()) {
      setResults([]);
      return;
    }

    const delayDebounceFn = setTimeout(() => {
      performSearch();
    }, 500);

    return () => clearTimeout(delayDebounceFn);
  }, [searchQuery, selectedCategory, recentSearches]);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 z-50 bg-[#0F1117] flex flex-col"
        >
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-[#2A2D3A]">
            <button
              onClick={() => setOpen(false)}
              className="p-2 text-white hover:text-primary transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
            <div className="flex-1 max-w-2xl mx-auto relative">
              <input
                type="text"
                placeholder="گەڕان بۆ فیلم، زنجیرە، ئەنیمە..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#1A1D27] text-white rounded-full py-3 px-12 focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all placeholder:text-[#8A8FA8]"
                dir="rtl"
                autoFocus
              />
              <SearchIcon className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#8A8FA8]" />
              {searchQuery && (
                <button 
                  onClick={() => setSearchQuery("")}
                  className="absolute left-4 top-1/2 -translate-y-1/2 p-1 text-[#8A8FA8] hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
            <div className="w-10" /> {/* Spacer for centering */}
          </div>

          {/* Categories */}
          <div className="p-4 flex justify-center gap-2 md:gap-4 overflow-x-auto no-scrollbar border-b border-[#2A2D3A]/50">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-full whitespace-nowrap transition-all ${
                  selectedCategory === cat.id
                    ? "bg-primary text-white"
                    : "bg-[#1A1D27] text-[#8A8FA8] hover:bg-[#2A2D3A] hover:text-white"
                }`}
              >
                <span>{cat.icon}</span>
                <span className="font-medium">{cat.label}</span>
              </button>
            ))}
          </div>

          {/* Content Area */}
          <div className="flex-1 overflow-y-auto p-4">
            {!searchQuery ? (
              <div className="max-w-2xl mx-auto mt-8">
                {recentSearches.length > 0 ? (
                  <>
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-white font-bold flex items-center gap-2">
                        <Clock className="w-5 h-5" />
                        گەڕانەکانی پێشوو
                      </h3>
                      <button 
                        onClick={() => {
                          setRecentSearches([]);
                          localStorage.removeItem("recentSearches");
                        }}
                        className="text-sm text-[#8A8FA8] hover:text-white"
                      >
                        سڕینەوە
                      </button>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {recentSearches.map((term) => (
                        <button
                          key={term}
                          onClick={() => setSearchQuery(term)}
                          className="px-4 py-2 rounded-full bg-[#1A1D27] text-[#8A8FA8] hover:bg-[#2A2D3A] hover:text-white transition-colors text-sm"
                        >
                          {term}
                        </button>
                      ))}
                    </div>
                  </>
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-[#8A8FA8] space-y-4 py-20">
                    <SearchIcon className="w-16 h-16 opacity-20" />
                    <p className="text-lg">دەست بکە بە گەڕان...</p>
                  </div>
                )}
              </div>
            ) : loading ? (
              <div className="flex justify-center items-center py-20">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
              </div>
            ) : results.length === 0 ? (
              <div className="text-center text-[#8A8FA8] py-20">
                <p className="text-xl mb-2">هیچ ئەنجامێک نەدۆزرایەوە بۆ &quot;{searchQuery}&quot;</p>
                <p className="text-sm">تکایە وشەیەکی تر تاقی بکەرەوە</p>
              </div>
            ) : (
              <div className="container mx-auto">
                <div className="mb-6 text-[#8A8FA8]">
                  {results.length} ئەنجام دۆزرایەوە
                </div>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
                  {results.map((item) => (
                    <ContentCard
                      key={item.id}
                      id={item.id}
                      title={item.title}
                      image={item.poster || `https://picsum.photos/seed/${item.id}/400/600`}
                      views={item.views ? `${(item.views / 1000).toFixed(1)}K` : "0"}
                      tags={item.tags || []}
                      type={item.type}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
