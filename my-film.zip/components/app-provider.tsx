"use client";

import { useEffect } from "react";
import { useAppStore } from "@/store/use-app-store";

export function AppProvider({ children }: { children: React.ReactNode }) {
  const language = useAppStore((state) => state.language);

  useEffect(() => {
    const dir = language === "en" ? "ltr" : "rtl";
    document.documentElement.dir = dir;
    document.documentElement.lang = language;
  }, [language]);

  return <>{children}</>;
}
