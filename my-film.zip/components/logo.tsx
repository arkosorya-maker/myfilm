import { cn } from "@/lib/utils";

export function Logo({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={cn("w-10 h-10", className)}
    >
      <rect width="100" height="100" rx="20" fill="#0D1117" />
      {/* Camera Body / M F */}
      <path
        d="M25 40V70H35V50L45 60L55 50V70H65V40H55L45 50L35 40H25Z"
        fill="white"
      />
      {/* Red dot (lens) */}
      <circle cx="50" cy="25" r="8" fill="#E31C25" />
      {/* Red triangle (play button) */}
      <path d="M75 45L85 55L75 65V45Z" fill="#E31C25" />
    </svg>
  );
}
