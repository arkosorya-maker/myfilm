"use client";

import Link from "next/link";
import Image from "next/image";
import { Menu, Search, User, LogOut, LayoutDashboard } from "lucide-react";
import { useAppStore } from "@/store/use-app-store";
import { Logo } from "./logo";
import { useAuth } from "./firebase-provider";
import { auth } from "@/lib/firebase";
import { signOut } from "firebase/auth";

export function Header() {
  const setMenuOpen = useAppStore((state) => state.setMenuOpen);
  const setSearchOpen = useAppStore((state) => state.setSearchOpen);
  const { user, isAdmin } = useAuth();

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error("Error signing out:", error);
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-[#0A0C12]/90 backdrop-blur-md border-b border-[#2A2D3A]">
      <div className="container mx-auto px-4 h-14 md:h-16 flex items-center justify-between">
        {/* Right side (RTL) - Menu & Logo */}
        <div className="flex items-center gap-4">
          <button
            onClick={() => setMenuOpen(true)}
            className="p-2 -mr-2 text-white hover:text-primary transition-colors"
            aria-label="Open Menu"
          >
            <Menu className="w-6 h-6" />
          </button>
          <Link href="/" className="flex items-center gap-2">
            <Logo className="w-8 h-8 md:w-10 md:h-10" />
            <span className="text-white font-bold text-lg md:text-xl tracking-tight hidden sm:block">
              My Film
            </span>
          </Link>
        </div>

        {/* Left side (RTL) - Search & Login/Profile */}
        <div className="flex items-center gap-3 md:gap-4">
          <button
            onClick={() => setSearchOpen(true)}
            className="p-2 text-white hover:text-primary transition-colors"
            aria-label="Search"
          >
            <Search className="w-5 h-5 md:w-6 md:h-6" />
          </button>
          
          {user ? (
            <div className="flex items-center gap-2">
              {isAdmin && (
                <Link
                  href="/admin"
                  className="p-2 text-white hover:text-primary transition-colors hidden sm:block"
                  aria-label="Admin Dashboard"
                >
                  <LayoutDashboard className="w-5 h-5" />
                </Link>
              )}
              <Link
                href="/profile"
                className="flex items-center gap-2 px-3 py-1.5 md:px-4 md:py-2 rounded-full hover:bg-white/5 transition-colors"
              >
                {user.photoURL ? (
                  <div className="w-6 h-6 relative rounded-full overflow-hidden">
                    <Image src={user.photoURL} alt="Profile" fill className="object-cover" referrerPolicy="no-referrer" />
                  </div>
                ) : (
                  <User className="w-5 h-5 text-blue-500" />
                )}
                <span className="text-white text-sm md:text-base font-medium hidden sm:block">
                  {user.displayName || "پڕۆفایل"}
                </span>
              </Link>
              <button
                onClick={handleLogout}
                className="p-2 text-white hover:text-red-500 transition-colors"
                aria-label="Logout"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          ) : (
            <Link
              href="/login"
              className="flex items-center gap-2 px-3 py-1.5 md:px-4 md:py-2 rounded-full hover:bg-white/5 transition-colors"
            >
              <User className="w-5 h-5 text-blue-500" />
              <span className="text-white text-sm md:text-base font-medium hidden sm:block">
                چوونەژوورەوە
              </span>
            </Link>
          )}
        </div>
      </div>
    </header>
  );
}
