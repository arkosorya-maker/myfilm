"use client";

import { useState, useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import { doc, setDoc, getDoc, updateDoc, serverTimestamp } from "firebase/firestore";
import { ref, uploadBytesResumable, getDownloadURL } from "firebase/storage";
import { db, storage } from "@/lib/firebase";
import { Save, ArrowLeft, Loader2, UploadCloud } from "lucide-react";
import Link from "next/link";
import Image from "next/image";

interface ContentFormProps {
  contentId?: string;
  initialType?: string;
}

export default function ContentForm({ contentId, initialType = "movie" }: ContentFormProps) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(!!contentId);
  const [error, setError] = useState("");
  const [uploadingPoster, setUploadingPoster] = useState(false);
  const [uploadingBackdrop, setUploadingBackdrop] = useState(false);
  
  const posterInputRef = useRef<HTMLInputElement>(null);
  const backdropInputRef = useRef<HTMLInputElement>(null);

  const [formData, setFormData] = useState({
    id: "",
    title: "",
    originalTitle: "",
    type: initialType,
    description: "",
    poster: "",
    backdrop: "",
    year: "",
    duration: "",
    rating: "",
    tags: "",
    videoUrl: "",
    isLive: false,
    region: "local", // For channels: local or world
  });

  useEffect(() => {
    async function fetchContent() {
      try {
        const docRef = doc(db, "content", contentId!);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = docSnap.data();
          setFormData({
            ...data,
            tags: data.tags ? data.tags.join(", ") : "",
            region: data.region || "local",
          } as any);
        } else {
          setError("Content not found");
        }
      } catch (err) {
        console.error("Error fetching content:", err);
        setError("Failed to load content");
      } finally {
        setFetching(false);
      }
    }

    if (contentId) {
      fetchContent();
    }
  }, [contentId]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    const val = type === "checkbox" ? (e.target as HTMLInputElement).checked : value;
    setFormData((prev) => ({ ...prev, [name]: val }));
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, field: "poster" | "backdrop") => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      setError("Please select an image file.");
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      setError("Image size should be less than 5MB.");
      return;
    }

    setError("");
    if (field === "poster") setUploadingPoster(true);
    else setUploadingBackdrop(true);

    try {
      const fileExtension = file.name.split('.').pop();
      const fileName = `${Date.now()}_${Math.random().toString(36).substring(2, 9)}.${fileExtension}`;
      const storageRef = ref(storage, `content_images/${field}s/${fileName}`);
      
      const uploadTask = uploadBytesResumable(storageRef, file);

      uploadTask.on(
        "state_changed",
        (snapshot) => {
          const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
          console.log(`Upload is ${progress}% done`);
        },
        (error) => {
          console.error("Upload failed:", error);
          setError(`Failed to upload ${field}.`);
          if (field === "poster") setUploadingPoster(false);
          else setUploadingBackdrop(false);
        },
        async () => {
          const downloadURL = await getDownloadURL(uploadTask.snapshot.ref);
          setFormData(prev => ({ ...prev, [field]: downloadURL }));
          if (field === "poster") setUploadingPoster(false);
          else setUploadingBackdrop(false);
        }
      );
    } catch (err) {
      console.error("Error in upload process:", err);
      setError(`Failed to process ${field} upload.`);
      if (field === "poster") setUploadingPoster(false);
      else setUploadingBackdrop(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const id = contentId || formData.id || formData.title.toLowerCase().replace(/[^a-z0-9]+/g, "-");
      const contentRef = doc(db, "content", id);
      
      const dataToSave = {
        ...formData,
        id,
        tags: formData.tags.split(",").map(t => t.trim()).filter(t => t),
        updatedAt: serverTimestamp(),
      };

      if (contentId) {
        await updateDoc(contentRef, dataToSave);
      } else {
        await setDoc(contentRef, {
          ...dataToSave,
          views: 0,
          createdAt: serverTimestamp(),
        });
      }

      router.push("/admin/content");
    } catch (err: any) {
      console.error("Error saving content:", err);
      setError(err.message || "Failed to save content");
    } finally {
      setLoading(false);
    }
  };

  if (fetching) {
    return <div className="flex items-center justify-center h-64"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>;
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8 p-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/admin/content" className="p-2 bg-secondary rounded-lg hover:bg-secondary/80 transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <h2 className="text-3xl font-bold tracking-tight">{contentId ? "Edit Content" : "Add New Content"}</h2>
        </div>
      </div>

      {error && (
        <div className="bg-destructive/10 border border-destructive/20 text-destructive px-4 py-3 rounded-lg">
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} className="bg-card border border-border rounded-xl p-6 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {!contentId && (
            <div className="space-y-2">
              <label className="text-sm font-medium text-muted-foreground">ID (Optional, auto-generated if empty)</label>
              <input type="text" name="id" value={formData.id} onChange={handleChange} className="w-full bg-secondary/50 border border-border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50" placeholder="e.g. the-matrix-1999" />
            </div>
          )}
          
          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">Type *</label>
            <select name="type" value={formData.type} onChange={handleChange} required className="w-full bg-secondary/50 border border-border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50">
              <option value="movie">Movie</option>
              <option value="series">Series</option>
              <option value="anime">Anime</option>
              <option value="channel">Channel</option>
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">Title *</label>
            <input type="text" name="title" value={formData.title} onChange={handleChange} required className="w-full bg-secondary/50 border border-border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50" />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">Original Title</label>
            <input type="text" name="originalTitle" value={formData.originalTitle} onChange={handleChange} className="w-full bg-secondary/50 border border-border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50" />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">Poster URL *</label>
            <div className="flex gap-2">
              <input type="url" name="poster" value={formData.poster} onChange={handleChange} required className="flex-1 bg-secondary/50 border border-border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50" placeholder="https://..." />
              <input 
                type="file" 
                accept="image/*" 
                className="hidden" 
                ref={posterInputRef}
                onChange={(e) => handleFileUpload(e, "poster")}
              />
              <button 
                type="button"
                onClick={() => posterInputRef.current?.click()}
                disabled={uploadingPoster}
                className="bg-secondary border border-border rounded-lg px-4 py-2 hover:bg-secondary/80 transition-colors flex items-center justify-center min-w-[48px]"
              >
                {uploadingPoster ? <Loader2 className="w-5 h-5 animate-spin" /> : <UploadCloud className="w-5 h-5" />}
              </button>
            </div>
            {formData.poster && (
              <div className="mt-2 relative w-24 h-36 rounded overflow-hidden border border-border">
                <Image src={formData.poster} alt="Poster preview" fill className="object-cover" />
              </div>
            )}
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">Backdrop URL</label>
            <div className="flex gap-2">
              <input type="url" name="backdrop" value={formData.backdrop} onChange={handleChange} className="flex-1 bg-secondary/50 border border-border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50" placeholder="https://..." />
              <input 
                type="file" 
                accept="image/*" 
                className="hidden" 
                ref={backdropInputRef}
                onChange={(e) => handleFileUpload(e, "backdrop")}
              />
              <button 
                type="button"
                onClick={() => backdropInputRef.current?.click()}
                disabled={uploadingBackdrop}
                className="bg-secondary border border-border rounded-lg px-4 py-2 hover:bg-secondary/80 transition-colors flex items-center justify-center min-w-[48px]"
              >
                {uploadingBackdrop ? <Loader2 className="w-5 h-5 animate-spin" /> : <UploadCloud className="w-5 h-5" />}
              </button>
            </div>
            {formData.backdrop && (
              <div className="mt-2 relative w-full h-24 rounded overflow-hidden border border-border">
                <Image src={formData.backdrop} alt="Backdrop preview" fill className="object-cover" />
              </div>
            )}
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">Video URL (M3U8/MP4)</label>
            <input type="url" name="videoUrl" value={formData.videoUrl} onChange={handleChange} className="w-full bg-secondary/50 border border-border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50" placeholder="https://..." />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">Year</label>
            <input type="text" name="year" value={formData.year} onChange={handleChange} className="w-full bg-secondary/50 border border-border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50" placeholder="2024" />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">Duration</label>
            <input type="text" name="duration" value={formData.duration} onChange={handleChange} className="w-full bg-secondary/50 border border-border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50" placeholder="120 min" />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">Rating</label>
            <input type="text" name="rating" value={formData.rating} onChange={handleChange} className="w-full bg-secondary/50 border border-border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50" placeholder="8.5" />
          </div>

          <div className="space-y-2 md:col-span-2">
            <label className="text-sm font-medium text-muted-foreground">Tags (comma separated)</label>
            <input type="text" name="tags" value={formData.tags} onChange={handleChange} className="w-full bg-secondary/50 border border-border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50" placeholder="Action, Sci-Fi, Thriller" />
          </div>

          <div className="space-y-2 md:col-span-2">
            <label className="text-sm font-medium text-muted-foreground">Description</label>
            <textarea name="description" value={formData.description} onChange={handleChange} rows={4} className="w-full bg-secondary/50 border border-border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50" />
          </div>

          {formData.type === "channel" && (
            <>
              <div className="space-y-2 md:col-span-2 flex items-center gap-3">
                <input type="checkbox" name="isLive" checked={formData.isLive} onChange={handleChange} id="isLive" className="w-5 h-5 rounded border-border text-primary focus:ring-primary/50 bg-secondary/50" />
                <label htmlFor="isLive" className="text-sm font-medium text-muted-foreground cursor-pointer">Is Live Broadcast?</label>
              </div>
              <div className="space-y-2 md:col-span-2">
                <label className="text-sm font-medium text-muted-foreground">Region</label>
                <select name="region" value={formData.region} onChange={handleChange} className="w-full bg-secondary/50 border border-border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50">
                  <option value="local">Local (ناوخۆ)</option>
                  <option value="world">World (جیهانی)</option>
                </select>
              </div>
            </>
          )}
        </div>

        <div className="pt-6 border-t border-border flex justify-end">
          <button type="submit" disabled={loading} className="bg-primary text-white px-6 py-2 rounded-lg flex items-center gap-2 hover:bg-primary/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
            {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
            <span>{contentId ? "Update Content" : "Save Content"}</span>
          </button>
        </div>
      </form>
    </div>
  );
}
