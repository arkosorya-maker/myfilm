"use client";

import { motion, AnimatePresence } from "motion/react";
import Link from "next/link";
import { X, Search, User, ChevronDown } from "lucide-react";
import { useAppStore } from "@/store/use-app-store";
import { useState } from "react";

const menuItems = [
  { label: "سەرەتا", href: "/" },
  { label: "فیلمەکان", href: "/movies" },
  { label: "زنجیرەکان", href: "/series" },
  { label: "ئەنیمەکان", href: "/anime" },
];

export function NavigationMenu() {
  const isOpen = useAppStore((state) => state.isMenuOpen);
  const setOpen = useAppStore((state) => state.setMenuOpen);
  const setSearchOpen = useAppStore((state) => state.setSearchOpen);
  const [channelsOpen, setChannelsOpen] = useState(false);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25 }}
          className="fixed inset-0 z-50 bg-[#0F1117]/95 backdrop-blur-xl flex flex-col"
        >
          <div className="flex-1 overflow-y-auto pt-20 pb-24 px-6 flex flex-col items-center justify-center space-y-8">
            {menuItems.map((item, i) => (
              <motion.div
                key={item.href}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
              >
                <Link
                  href={item.href}
                  onClick={() => setOpen(false)}
                  className="text-3xl md:text-5xl font-bold text-white hover:text-primary transition-colors"
                >
                  {item.label}
                </Link>
              </motion.div>
            ))}

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: menuItems.length * 0.05 }}
              className="flex flex-col items-center"
            >
              <button
                onClick={() => setChannelsOpen(!channelsOpen)}
                className="text-3xl md:text-5xl font-bold text-white hover:text-primary transition-colors flex items-center gap-2"
              >
                کەناڵەکان
                <ChevronDown
                  className={`w-8 h-8 transition-transform ${
                    channelsOpen ? "rotate-180" : ""
                  }`}
                />
              </button>
              <AnimatePresence>
                {channelsOpen && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="flex flex-col items-center gap-4 mt-6 overflow-hidden"
                  >
                    <Link
                      href="/channels?tab=local"
                      onClick={() => setOpen(false)}
                      className="text-xl md:text-2xl text-gray-300 hover:text-white transition-colors"
                    >
                      کەناڵی ناوخۆ
                    </Link>
                    <Link
                      href="/channels?tab=world"
                      onClick={() => setOpen(false)}
                      className="text-xl md:text-2xl text-gray-300 hover:text-white transition-colors"
                    >
                      کەناڵی جیهانی
                    </Link>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          </div>

          {/* Bottom Bar */}
          <div className="absolute bottom-0 left-0 right-0 p-6 flex justify-between items-center bg-gradient-to-t from-[#0A0C12] to-transparent">
            {/* Left side (RTL) - Login & Search */}
            <div className="flex items-center gap-6">
              <Link
                href="/login"
                onClick={() => setOpen(false)}
                className="flex items-center gap-2 text-white hover:text-primary transition-colors"
              >
                <User className="w-6 h-6 text-blue-500" />
                <span className="font-medium text-lg">چوونەژوورەوە</span>
              </Link>
              <button
                onClick={() => {
                  setOpen(false);
                  setSearchOpen(true);
                }}
                className="p-2 text-white hover:text-primary transition-colors"
              >
                <Search className="w-6 h-6" />
              </button>
            </div>

            {/* Right side (RTL) - Close Button */}
            <button
              onClick={() => setOpen(false)}
              className="p-3 bg-white/10 rounded-full text-white hover:bg-primary hover:text-white transition-all"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
