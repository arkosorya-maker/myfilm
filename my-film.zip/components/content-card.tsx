"use client";

import Image from "next/image";
import Link from "next/link";
import { Eye } from "lucide-react";
import { motion } from "motion/react";

interface ContentCardProps {
  id: string;
  title: string;
  image: string;
  views: string;
  tags: string[];
  type: "movie" | "series" | "anime" | "channel";
}

export function ContentCard({
  id,
  title,
  image,
  views,
  tags,
  type,
}: ContentCardProps) {
  return (
    <Link href={`/${type}/${id}`}>
      <motion.div
        whileHover={{ scale: 1.03 }}
        transition={{ duration: 0.15, ease: "easeOut" }}
        className="group relative flex flex-col gap-2 rounded-lg cursor-pointer"
      >
        {/* Poster Container */}
        <div className="relative aspect-[2/3] w-full overflow-hidden rounded-[10px] bg-[#1A1D27] shadow-lg group-hover:shadow-xl transition-shadow">
          <Image
            src={image}
            alt={title}
            fill
            className="object-cover transition-transform duration-300 group-hover:scale-105"
            sizes="(max-width: 768px) 50vw, (max-width: 1200px) 33vw, 20vw"
          />
          
          {/* View Count Badge */}
          <div className="absolute bottom-2 left-2 bg-black/60 backdrop-blur-sm px-2 py-1 rounded-full flex items-center gap-1.5 text-white text-xs font-medium">
            <Eye className="w-3.5 h-3.5" />
            <span>{views}</span>
          </div>
        </div>

        {/* Info Container */}
        <div className="flex flex-col gap-1 px-1">
          <h3 className="text-white font-semibold text-sm md:text-base line-clamp-2 text-right leading-snug">
            {title}
          </h3>
          <div className="flex flex-wrap gap-x-2 gap-y-1 justify-end">
            {tags.map((tag, idx) => (
              <span
                key={idx}
                className="text-[#E31C25] text-xs font-medium whitespace-nowrap"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>
      </motion.div>
    </Link>
  );
}
