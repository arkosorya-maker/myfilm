import ContentForm from "@/components/admin/content-form";

export default async function EditContentPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  return <ContentForm contentId={id} />;
}
