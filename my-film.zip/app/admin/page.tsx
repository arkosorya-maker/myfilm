"use client";

import { useEffect, useState } from "react";
import { collection, getDocs } from "firebase/firestore";
import { db } from "@/lib/firebase";
import Link from "next/link";
import { Film, Tv, Video, Radio, Users } from "lucide-react";

export default function AdminDashboard() {
  const [stats, setStats] = useState({
    movies: 0,
    series: 0,
    anime: 0,
    channels: 0,
    users: 0,
  });

  useEffect(() => {
    async function fetchStats() {
      try {
        const contentSnap = await getDocs(collection(db, "content"));
        const usersSnap = await getDocs(collection(db, "users"));
        
        const content = contentSnap.docs.map(doc => doc.data());
        
        setStats({
          movies: content.filter(c => c.type === "movie").length,
          series: content.filter(c => c.type === "series").length,
          anime: content.filter(c => c.type === "anime").length,
          channels: content.filter(c => c.type === "channel").length,
          users: usersSnap.size,
        });
      } catch (error) {
        console.error("Error fetching stats:", error);
      }
    }
    
    fetchStats();
  }, []);

  const statCards = [
    { title: "Movies", value: stats.movies, icon: Video, href: "/admin/content?type=movie", color: "text-blue-500", bg: "bg-blue-500/10" },
    { title: "Series", value: stats.series, icon: Tv, href: "/admin/content?type=series", color: "text-purple-500", bg: "bg-purple-500/10" },
    { title: "Anime", value: stats.anime, icon: Film, href: "/admin/content?type=anime", color: "text-pink-500", bg: "bg-pink-500/10" },
    { title: "Channels", value: stats.channels, icon: Radio, href: "/admin/content?type=channel", color: "text-green-500", bg: "bg-green-500/10" },
    { title: "Users", value: stats.users, icon: Users, href: "/admin/users", color: "text-orange-500", bg: "bg-orange-500/10" },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
        <p className="text-muted-foreground mt-2">Overview of your platform&apos;s content and users.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
        {statCards.map((stat, i) => (
          <Link key={i} href={stat.href} className="bg-card border border-border rounded-xl p-6 hover:border-primary/50 transition-colors group">
            <div className="flex items-center justify-between mb-4">
              <div className={`w-12 h-12 rounded-lg ${stat.bg} ${stat.color} flex items-center justify-center group-hover:scale-110 transition-transform`}>
                <stat.icon className="w-6 h-6" />
              </div>
              <span className="text-3xl font-bold">{stat.value}</span>
            </div>
            <h3 className="text-muted-foreground font-medium">{stat.title}</h3>
          </Link>
        ))}
      </div>
    </div>
  );
}
