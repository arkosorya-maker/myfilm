import type { Metadata } from 'next';
import { Inter, Noto_Naskh_Arabic } from 'next/font/google';
import './globals.css';
import { ThemeProvider } from '@/components/theme-provider';
import { AppProvider } from '@/components/app-provider';
import { FirebaseProvider } from '@/components/firebase-provider';

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' });
const notoNaskh = Noto_Naskh_Arabic({ subsets: ['arabic'], variable: '--font-noto' });

export const metadata: Metadata = {
  title: 'My Film',
  description: 'A full streaming website with RTL support, dark mode, and cinematic design.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ku" dir="rtl" suppressHydrationWarning>
      <body className={`${inter.variable} ${notoNaskh.variable} font-noto bg-background text-foreground min-h-screen flex flex-col antialiased`}>
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem={false}>
          <FirebaseProvider>
            <AppProvider>
              {children}
            </AppProvider>
          </FirebaseProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
