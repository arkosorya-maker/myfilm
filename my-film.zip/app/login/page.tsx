"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft, Mail, Lock, Chrome, Loader2 } from "lucide-react";
import { Logo } from "@/components/logo";
import { auth, googleProvider } from "@/lib/firebase";
import { signInWithEmailAndPassword, signInWithPopup } from "firebase/auth";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      await signInWithEmailAndPassword(auth, email, password);
      router.push("/");
    } catch (err: any) {
      setError("ئیمەیڵ یان وشەی نهێنی هەڵەیە");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setLoading(true);
    setError("");
    try {
      await signInWithPopup(auth, googleProvider);
      router.push("/");
    } catch (err: any) {
      setError("هەڵەیەک ڕوویدا لە کاتی چوونەژوورەوە بە گووگڵ");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0F1117] flex flex-col items-center justify-center p-4 relative">
      {/* Back Button */}
      <Link
        href="/"
        className="absolute top-6 left-6 flex items-center gap-2 text-[#8A8FA8] hover:text-white transition-colors"
      >
        <ArrowLeft className="w-5 h-5" />
        <span className="font-medium">گەڕانەوە</span>
      </Link>

      {/* Login Card */}
      <div className="w-full max-w-md bg-[#1A1D27] rounded-2xl p-8 shadow-2xl border border-[#2A2D3A]">
        <div className="flex flex-col items-center mb-8">
          <Logo className="w-16 h-16 mb-4" />
          <h1 className="text-2xl font-bold text-white mb-2">بەخێربێیتەوە بۆ My Film</h1>
          <p className="text-[#8A8FA8] text-center">
            تکایە زانیارییەکانت بنووسە بۆ چوونەژوورەوە
          </p>
        </div>

        {error && (
          <div className="bg-destructive/10 border border-destructive/20 text-destructive px-4 py-3 rounded-lg mb-6 text-center text-sm">
            {error}
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-300 block text-right">
              ئیمەیڵ
            </label>
            <div className="relative">
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@example.com"
                className="w-full bg-[#0F1117] border border-[#2A2D3A] rounded-lg px-4 py-3 text-white focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-colors text-right"
                dir="ltr"
              />
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#8A8FA8]" />
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Link
                href="/forgot-password"
                className="text-sm text-primary hover:underline"
              >
                وشەی نهێنیت بیرچووە؟
              </Link>
              <label className="text-sm font-medium text-gray-300 block text-right">
                وشەی نهێنی
              </label>
            </div>
            <div className="relative">
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-[#0F1117] border border-[#2A2D3A] rounded-lg px-4 py-3 text-white focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-colors text-right"
                dir="ltr"
              />
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#8A8FA8]" />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-[#E31C25] text-white font-bold py-3 rounded-lg hover:bg-red-700 transition-colors shadow-lg shadow-red-500/20 mt-6 flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : "چوونەژوورەوە"}
          </button>
        </form>

        <div className="mt-6 flex items-center gap-4">
          <div className="flex-1 h-px bg-[#2A2D3A]" />
          <span className="text-[#8A8FA8] text-sm">یان</span>
          <div className="flex-1 h-px bg-[#2A2D3A]" />
        </div>

        <button
          type="button"
          onClick={handleGoogleLogin}
          disabled={loading}
          className="w-full mt-6 bg-white text-black font-bold py-3 rounded-lg hover:bg-gray-100 transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
        >
          <Chrome className="w-5 h-5" />
          چوونەژوورەوە بە Google
        </button>

        <p className="mt-8 text-center text-[#8A8FA8] text-sm">
          هەژمارت نییە؟{" "}
          <Link href="/register" className="text-white hover:text-primary font-medium transition-colors">
            خۆت تۆمار بکە
          </Link>
        </p>
      </div>
    </div>
  );
}
