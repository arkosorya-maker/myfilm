"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import { useTheme } from "next-themes";
import { useRouter } from "next/navigation";
import { Moon, Sun, Globe, Bookmark, Star, LogOut, Settings, X, User } from "lucide-react";
import { Header } from "@/components/header";
import { NavigationMenu } from "@/components/navigation-menu";
import { SearchOverlay } from "@/components/search-overlay";
import { useAppStore } from "@/store/use-app-store";
import { ContentCard } from "@/components/content-card";
import { useAuth } from "@/components/firebase-provider";
import { auth } from "@/lib/firebase";
import { signOut } from "firebase/auth";

const MOCK_SAVED = Array.from({ length: 4 }).map((_, i) => ({
  id: `saved${i}`,
  title: "فیلمی سەیڤکراو",
  image: `https://picsum.photos/seed/saved${i}/400/600`,
  views: "10K",
  tags: ["ئاکشن", "دراما"],
}));

export default function ProfilePage() {
  const { theme, setTheme } = useTheme();
  const { language, setLanguage } = useAppStore();
  const [activeTab, setActiveTab] = useState<"settings" | "saved" | "favorites">("settings");
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && !user) {
      router.push("/login");
    }
  }, [user, loading, router]);

  const handleLogout = async () => {
    try {
      await signOut(auth);
      router.push("/");
    } catch (error) {
      console.error("Error signing out:", error);
    }
  };

  if (loading || !user) {
    return (
      <div className="flex flex-col min-h-screen bg-background text-foreground transition-colors duration-300">
        <Header />
        <main className="flex-1 flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
        </main>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground transition-colors duration-300">
      <Header />
      <NavigationMenu />
      <SearchOverlay />

      <main className="flex-1 container mx-auto px-4 py-8 md:py-12">
        {/* Profile Header */}
        <div className="bg-card rounded-2xl p-6 md:p-8 shadow-xl border border-border flex flex-col md:flex-row items-center gap-6 md:gap-8 mb-8">
          <div className="relative w-24 h-24 md:w-32 md:h-32 rounded-full overflow-hidden border-4 border-primary shadow-lg shrink-0 flex items-center justify-center bg-secondary">
            {user.photoURL ? (
              <Image
                src={user.photoURL}
                alt="User Avatar"
                fill
                className="object-cover"
              />
            ) : (
              <User className="w-12 h-12 text-muted-foreground" />
            )}
          </div>
          <div className="flex-1 text-center md:text-right">
            <h1 className="text-2xl md:text-4xl font-bold mb-2">{user.displayName || "بەکارهێنەر"}</h1>
            <p className="text-muted mb-6">{user.email}</p>
            
            <div className="flex flex-wrap justify-center md:justify-end gap-4 md:gap-8">
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">١٢٤</div>
                <div className="text-sm text-muted">فیلم بینراوە</div>
              </div>
              <div className="w-px h-12 bg-border hidden md:block" />
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">٣٤٠</div>
                <div className="text-sm text-muted">کاتژمێر</div>
              </div>
              <div className="w-px h-12 bg-border hidden md:block" />
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">٤٥</div>
                <div className="text-sm text-muted">ئەستێرەکان</div>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex justify-center md:justify-start gap-2 md:gap-4 mb-8 overflow-x-auto no-scrollbar pb-2">
          {[
            { id: "settings", label: "ڕێکخستنەکان", icon: <Settings className="w-5 h-5" /> },
            { id: "saved", label: "سەیڤکراو", icon: <Bookmark className="w-5 h-5" /> },
            { id: "favorites", label: "ئەستێرەکان", icon: <Star className="w-5 h-5" /> },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-6 py-3 rounded-full font-medium transition-all whitespace-nowrap ${
                activeTab === tab.id
                  ? "bg-primary text-white shadow-lg shadow-primary/20"
                  : "bg-card text-muted hover:bg-secondary hover:text-foreground border border-border"
              }`}
            >
              {tab.icon}
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="bg-card rounded-2xl p-6 md:p-8 shadow-xl border border-border min-h-[400px]">
          {activeTab === "settings" && (
            <div className="space-y-8 max-w-2xl mx-auto">
              {/* Theme Toggle */}
              <div className="flex items-center justify-between p-4 rounded-xl bg-secondary/50 border border-border">
                <div className="flex items-center gap-3">
                  {theme === "dark" ? <Moon className="w-6 h-6 text-blue-400" /> : <Sun className="w-6 h-6 text-yellow-500" />}
                  <div>
                    <h3 className="font-bold text-lg">دۆخی ڕووناکی</h3>
                    <p className="text-sm text-muted">گۆڕینی ڕەنگی ماڵپەڕ</p>
                  </div>
                </div>
                <button
                  onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                  className="bg-background border border-border px-4 py-2 rounded-lg font-medium hover:bg-secondary transition-colors"
                >
                  {theme === "dark" ? "ڕووناک" : "تاریک"}
                </button>
              </div>

              {/* Language Toggle */}
              <div className="flex items-center justify-between p-4 rounded-xl bg-secondary/50 border border-border">
                <div className="flex items-center gap-3">
                  <Globe className="w-6 h-6 text-green-500" />
                  <div>
                    <h3 className="font-bold text-lg">زمان</h3>
                    <p className="text-sm text-muted">گۆڕینی زمانی ماڵپەڕ</p>
                  </div>
                </div>
                <select
                  value={language}
                  onChange={(e) => setLanguage(e.target.value as any)}
                  className="bg-background border border-border px-4 py-2 rounded-lg font-medium hover:bg-secondary transition-colors focus:outline-none focus:ring-2 focus:ring-primary"
                  dir="ltr"
                >
                  <option value="ku">کوردی (Kurdish)</option>
                  <option value="ar">عربي (Arabic)</option>
                  <option value="en">English</option>
                </select>
              </div>

              {/* Logout */}
              <div className="pt-8 border-t border-border flex justify-center">
                <button 
                  onClick={handleLogout}
                  className="flex items-center gap-2 text-red-500 hover:text-red-600 font-bold bg-red-500/10 px-8 py-3 rounded-full transition-colors"
                >
                  <LogOut className="w-5 h-5" />
                  چوونەدەرەوە
                </button>
              </div>
            </div>
          )}

          {activeTab === "saved" && (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 md:gap-6">
              {MOCK_SAVED.map((item) => (
                <div key={item.id} className="relative group">
                  <ContentCard {...item} type="movie" />
                  <button className="absolute top-2 right-2 p-2 bg-black/60 backdrop-blur-sm rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-500">
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}

          {activeTab === "favorites" && (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 md:gap-6">
              {MOCK_SAVED.map((item) => (
                <div key={item.id} className="relative group">
                  <ContentCard {...item} type="movie" />
                  <div className="absolute top-2 left-2 p-1.5 bg-black/60 backdrop-blur-sm rounded-full text-yellow-500">
                    <Star className="w-4 h-4 fill-current" />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}


