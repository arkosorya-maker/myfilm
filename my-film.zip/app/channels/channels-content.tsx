"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { useSearchParams, useRouter } from "next/navigation";
import { Header } from "@/components/header";
import { NavigationMenu } from "@/components/navigation-menu";
import { SearchOverlay } from "@/components/search-overlay";
import { motion } from "motion/react";
import { collection, query, where, getDocs } from "firebase/firestore";
import { db } from "@/lib/firebase";

export function ChannelsContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const tabParam = searchParams.get("tab");
  const [activeTab, setActiveTab] = useState<"local" | "world">("local");
  const [channels, setChannels] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const currentTab = tabParam === "world" || tabParam === "local" ? tabParam : activeTab;

  useEffect(() => {
    async function fetchChannels() {
      setLoading(true);
      try {
        const q = query(
          collection(db, "content"), 
          where("type", "==", "channel"),
          where("region", "==", currentTab)
        );
        const snapshot = await getDocs(q);
        const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setChannels(data);
      } catch (error) {
        console.error("Error fetching channels:", error);
      } finally {
        setLoading(false);
      }
    }
    fetchChannels();
  }, [currentTab]);

  const handleTabChange = (tab: "local" | "world") => {
    setActiveTab(tab);
    router.push(`/channels?tab=${tab}`);
  };

  const displayedChannels = channels;

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <Header />
      <NavigationMenu />
      <SearchOverlay />

      <main className="flex-1 container mx-auto px-4 py-8 md:py-12">
        <div className="flex flex-col items-center mb-12">
          <h1 className="text-3xl md:text-5xl font-bold mb-8">کەناڵەکان</h1>
          
          {/* Tabs */}
          <div className="flex p-1 bg-card rounded-full border border-border">
            <button
              onClick={() => handleTabChange("local")}
              className={`px-8 py-3 rounded-full font-medium transition-all ${
                currentTab === "local"
                  ? "bg-primary text-white shadow-lg"
                  : "text-muted hover:text-foreground"
              }`}
            >
              کەناڵی ناوخۆ
            </button>
            <button
              onClick={() => handleTabChange("world")}
              className={`px-8 py-3 rounded-full font-medium transition-all ${
                currentTab === "world"
                  ? "bg-primary text-white shadow-lg"
                  : "text-muted hover:text-foreground"
              }`}
            >
              کەناڵی جیهانی
            </button>
          </div>
        </div>

        {/* Grid */}
        {loading ? (
          <div className="flex justify-center items-center py-20">
            <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
          </div>
        ) : displayedChannels.length === 0 ? (
          <div className="text-center text-muted-foreground py-20">
            هیچ کەناڵێک نەدۆزرایەوە.
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4 md:gap-6">
            {displayedChannels.map((channel) => (
              <Link key={channel.id} href={`/watch/channel/${channel.id}`}>
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  className="bg-card rounded-2xl p-6 flex flex-col items-center gap-4 border border-border hover:border-primary/50 transition-colors group cursor-pointer relative overflow-hidden"
                >
                  {/* Live Badge */}
                  {channel.isLive && (
                    <div className="absolute top-3 right-3 bg-red-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full animate-pulse">
                      LIVE
                    </div>
                  )}

                  <div className="relative w-24 h-24 rounded-full overflow-hidden bg-secondary shadow-inner">
                    <Image
                      src={channel.poster}
                      alt={channel.title}
                      fill
                      className="object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                  </div>
                  <h3 className="font-bold text-center text-sm md:text-base line-clamp-2">
                    {channel.title}
                  </h3>
                </motion.div>
              </Link>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
