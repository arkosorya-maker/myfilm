"use client";

import { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { Header } from "@/components/header";
import { NavigationMenu } from "@/components/navigation-menu";
import { SearchOverlay } from "@/components/search-overlay";
import { motion } from "motion/react";

const MOCK_LOCAL_CHANNELS = Array.from({ length: 12 }).map((_, i) => ({
  id: `local${i}`,
  name: "کەناڵی ناوخۆیی",
  logo: `https://picsum.photos/seed/local${i}/200/200`,
  isLive: i < 3,
}));

const MOCK_WORLD_CHANNELS = Array.from({ length: 12 }).map((_, i) => ({
  id: `world${i}`,
  name: "کەناڵی جیهانی",
  logo: `https://picsum.photos/seed/world${i}/200/200`,
  isLive: i < 5,
}));

import { Suspense } from "react";
import { ChannelsContent } from "./channels-content";

export default function ChannelsPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-background" />}>
      <ChannelsContent />
    </Suspense>
  );
}

