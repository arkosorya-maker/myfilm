"use client";

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <html>
      <body>
        <div className="flex flex-col items-center justify-center min-h-screen bg-black text-white p-4">
          <h2 className="text-2xl font-bold mb-4 text-red-500">Global Error!</h2>
          <div className="bg-gray-900 p-4 rounded-lg border border-gray-800 max-w-2xl w-full overflow-auto mb-6">
            <p className="text-sm font-mono text-red-400">{error.message}</p>
            {error.stack && (
              <pre className="text-xs text-gray-400 mt-4 whitespace-pre-wrap">
                {error.stack}
              </pre>
            )}
          </div>
          <button
            onClick={() => reset()}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            Try again
          </button>
        </div>
      </body>
    </html>
  );
}
