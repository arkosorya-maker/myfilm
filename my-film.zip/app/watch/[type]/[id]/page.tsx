"use client";

import * as React from "react";
import { use, useEffect, useState } from "react";
import Link from "next/link";
import { ArrowRight, Settings, Maximize, Play, Pause, Volume2, SkipForward, Loader2 } from "lucide-react";
import { Plyr } from "plyr-react";
import "plyr-react/plyr.css";
import { doc, getDoc } from "firebase/firestore";
import { db } from "@/lib/firebase";

export default function WatchPage({
  params,
}: {
  params: Promise<{ type: string; id: string }>;
}) {
  const { type, id } = use(params);
  const [content, setContent] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    async function fetchContent() {
      try {
        const docRef = doc(db, "content", id);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          setContent(docSnap.data());
        }
      } catch (error) {
        console.error("Error fetching video:", error);
      } finally {
        setLoading(false);
      }
    }
    fetchContent();
  }, [id]);

  if (loading) {
    return (
      <div className="flex flex-col min-h-screen bg-black text-white items-center justify-center">
        <Loader2 className="w-12 h-12 text-primary animate-spin" />
      </div>
    );
  }

  if (!content) {
    return (
      <div className="flex flex-col min-h-screen bg-black text-white items-center justify-center text-2xl">
        Video not found
      </div>
    );
  }

  // Use the videoUrl from Firestore, or fallback to a blank video
  const videoSrc = {
    type: "video",
    sources: [
      {
        src: content.videoUrl || "https://cdn.plyr.io/static/blank.mp4",
        type: "video/mp4",
        size: 720,
      },
      {
        src: content.videoUrl || "https://cdn.plyr.io/static/blank.mp4",
        type: "video/mp4",
        size: 1080,
      },
    ],
  };

  return (
    <div className="flex flex-col min-h-screen bg-black text-white">
      {/* Top Bar (Immersive) */}
      <div className="absolute top-0 left-0 right-0 p-4 md:p-6 z-50 flex items-center justify-between bg-gradient-to-b from-black/80 to-transparent">
        <Link
          href={`/${type}/${id}`}
          className="flex items-center gap-2 text-white/80 hover:text-white transition-colors bg-black/40 px-4 py-2 rounded-full backdrop-blur-md"
        >
          <ArrowRight className="w-5 h-5" />
          <span className="font-medium">گەڕانەوە</span>
        </Link>
        <div className="text-white/80 font-medium bg-black/40 px-4 py-2 rounded-full backdrop-blur-md">
          {content.title}
        </div>
      </div>

      {/* Player Container */}
      <div className="flex-1 flex items-center justify-center relative w-full max-w-[1600px] mx-auto">
        <div className="w-full aspect-video bg-[#0F1117] relative shadow-2xl">
          <Plyr
            source={videoSrc as any}
            options={{
              controls: [
                "play-large",
                "play",
                "progress",
                "current-time",
                "mute",
                "volume",
                "captions",
                "settings",
                "pip",
                "airplay",
                "fullscreen",
              ],
              settings: ["captions", "quality", "speed"],
            }}
          />
        </div>
      </div>

      {/* Bottom Info */}
      <div className="p-6 md:p-8 max-w-[1600px] mx-auto w-full flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold mb-2">{content.title}</h1>
          {(content.type === "series" || content.type === "anime") && (
            <p className="text-[#8A8FA8] text-lg">ئەڵقەی ١ - وەرزی ١</p>
          )}
        </div>
        
        <div className="flex items-center gap-4">
          <button className="flex items-center gap-2 bg-[#1A1D27] text-white px-6 py-3 rounded-full font-medium hover:bg-[#2A2D3A] transition-colors border border-[#2A2D3A]">
            <Settings className="w-5 h-5" />
            ڕێکخستنەکان
          </button>
          {(content.type === "series" || content.type === "anime") && (
            <button className="flex items-center gap-2 bg-[#E31C25] text-white px-6 py-3 rounded-full font-bold hover:bg-red-700 transition-colors shadow-lg shadow-red-500/20">
              <SkipForward className="w-5 h-5" />
              ئەڵقەی داهاتوو
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
