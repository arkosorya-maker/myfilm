"use client";

import { useEffect, useState, use } from "react";
import Image from "next/image";
import Link from "next/link";
import { Play, Bookmark, Star, Clock, Calendar, StarIcon, Loader2 } from "lucide-react";
import { Header } from "@/components/header";
import { NavigationMenu } from "@/components/navigation-menu";
import { SearchOverlay } from "@/components/search-overlay";
import { ContentSection } from "@/components/content-section";
import { doc, getDoc, collection, query, where, limit, getDocs } from "firebase/firestore";
import { db } from "@/lib/firebase";

export default function ContentDetailPage({
  params,
}: {
  params: Promise<{ type: string; id: string }>;
}) {
  const { type, id } = use(params);
  
  const [content, setContent] = useState<any>(null);
  const [similarContent, setSimilarContent] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchDetails() {
      try {
        const docRef = doc(db, "content", id);
        const docSnap = await getDoc(docRef);
        
        if (docSnap.exists()) {
          const data = docSnap.data();
          setContent({ ...data, isSeries: data.type === "series" || data.type === "anime" });
          
          // Fetch similar content
          const q = query(
            collection(db, "content"),
            where("type", "==", data.type),
            limit(6)
          );
          const similarSnap = await getDocs(q);
          setSimilarContent(similarSnap.docs
            .filter(d => d.id !== id)
            .map(d => ({ id: d.id, ...d.data(), image: d.data().poster }))
          );
        }
      } catch (error) {
        console.error("Error fetching content details:", error);
      } finally {
        setLoading(false);
      }
    }

    fetchDetails();
  }, [id]);

  if (loading) {
    return (
      <div className="flex flex-col min-h-screen bg-[#0F1117]">
        <Header />
        <NavigationMenu />
        <SearchOverlay />
        <div className="flex-1 flex items-center justify-center">
          <Loader2 className="w-12 h-12 text-primary animate-spin" />
        </div>
      </div>
    );
  }

  if (!content) {
    return (
      <div className="flex flex-col min-h-screen bg-[#0F1117]">
        <Header />
        <NavigationMenu />
        <SearchOverlay />
        <div className="flex-1 flex items-center justify-center text-white text-2xl">
          Content not found
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen bg-[#0F1117]">
      <Header />
      <NavigationMenu />
      <SearchOverlay />

      <main className="flex-1">
        {/* Backdrop Section */}
        <div className="relative w-full h-[50vh] md:h-[70vh] max-h-[800px]">
          <Image
            src={content.backdrop || content.poster}
            alt={content.title}
            fill
            className="object-cover"
            priority
          />
          {/* Gradient Overlays */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#0F1117] via-[#0F1117]/60 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0F1117]/80 via-transparent to-[#0F1117]/80" />
        </div>

        {/* Content Info Section */}
        <div className="container mx-auto px-4 relative -mt-32 md:-mt-64 z-10">
          <div className="flex flex-col md:flex-row gap-6 md:gap-12">
            {/* Poster */}
            <div className="w-48 md:w-72 shrink-0 mx-auto md:mx-0">
              <div className="relative aspect-[2/3] rounded-xl overflow-hidden shadow-2xl border border-[#2A2D3A]">
                <Image
                  src={content.poster}
                  alt={content.title}
                  fill
                  className="object-cover"
                />
              </div>
            </div>

            {/* Details */}
            <div className="flex-1 flex flex-col justify-end pb-8">
              <h1 className="text-3xl md:text-5xl font-bold text-white mb-2">
                {content.title}
              </h1>
              {content.originalTitle && (
                <p className="text-xl md:text-2xl text-[#8A8FA8] mb-6 font-medium">
                  {content.originalTitle}
                </p>
              )}

              {/* Meta Info */}
              <div className="flex flex-wrap items-center gap-4 md:gap-6 text-[#8A8FA8] mb-6 text-sm md:text-base">
                {content.year && (
                  <div className="flex items-center gap-1.5">
                    <Calendar className="w-5 h-5" />
                    <span>{content.year}</span>
                  </div>
                )}
                {content.duration && (
                  <div className="flex items-center gap-1.5">
                    <Clock className="w-5 h-5" />
                    <span>{content.duration}</span>
                  </div>
                )}
                {content.rating && (
                  <div className="flex items-center gap-1.5 text-yellow-500">
                    <StarIcon className="w-5 h-5 fill-current" />
                    <span className="font-bold text-white">{content.rating}</span>
                  </div>
                )}
              </div>

              {/* Tags */}
              {content.tags && content.tags.length > 0 && (
                <div className="flex flex-wrap gap-2 mb-8">
                  {content.tags.map((tag: string) => (
                    <span
                      key={tag}
                      className="bg-[#E31C25]/10 text-[#E31C25] px-3 py-1 rounded-full text-sm font-medium border border-[#E31C25]/20"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              )}

              {/* Description */}
              {content.description && (
                <p className="text-gray-300 text-base md:text-lg leading-relaxed mb-8 max-w-3xl">
                  {content.description}
                </p>
              )}

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-4">
                <Link
                  href={`/watch/${type}/${id}`}
                  className="flex items-center gap-2 bg-[#E31C25] text-white px-8 py-3.5 rounded-full font-bold text-lg hover:bg-red-700 transition-colors shadow-lg shadow-red-500/20"
                >
                  <Play className="w-6 h-6 fill-current" />
                  سەیرکردن
                </Link>
                <button className="flex items-center gap-2 bg-[#1A1D27] text-white px-6 py-3.5 rounded-full font-medium hover:bg-[#2A2D3A] transition-colors border border-[#2A2D3A]">
                  <Bookmark className="w-5 h-5" />
                  سەیڤ
                </button>
                <button className="flex items-center gap-2 bg-[#1A1D27] text-white px-6 py-3.5 rounded-full font-medium hover:bg-[#2A2D3A] transition-colors border border-[#2A2D3A]">
                  <Star className="w-5 h-5" />
                  ئەستێرە
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Series Episodes (if applicable) */}
        {content.isSeries && (
          <div className="container mx-auto px-4 py-12 border-t border-[#2A2D3A] mt-12">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-2xl font-bold text-white">ئەڵقەکان</h2>
              <select className="bg-[#1A1D27] text-white border border-[#2A2D3A] rounded-lg px-4 py-2 focus:outline-none focus:border-primary">
                <option>وەرزى ١</option>
                <option>وەرزى ٢</option>
              </select>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {Array.from({ length: 12 }).map((_, i) => (
                <Link
                  key={i}
                  href={`/watch/${type}/${id}?ep=${i + 1}`}
                  className="flex items-center gap-4 bg-[#1A1D27] p-3 rounded-xl hover:bg-[#2A2D3A] transition-colors border border-[#2A2D3A]/50 group"
                >
                  <div className="relative w-32 aspect-video rounded-lg overflow-hidden bg-black shrink-0">
                    <Image
                      src={content.backdrop || content.poster}
                      alt={`Episode ${i + 1}`}
                      fill
                      className="object-cover opacity-80 group-hover:opacity-100 transition-opacity"
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Play className="w-8 h-8 text-white opacity-0 group-hover:opacity-100 transition-opacity drop-shadow-lg" />
                    </div>
                  </div>
                  <div className="flex-1">
                    <h4 className="text-white font-medium mb-1">ئەڵقەی {i + 1}</h4>
                    <p className="text-[#8A8FA8] text-sm">45 خولەک</p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}

        {/* Similar Content */}
        {similarContent.length > 0 && (
          <div className="mt-12 border-t border-[#2A2D3A]">
            <ContentSection
              title="هاوشێوەکان"
              items={similarContent}
              type={type as any}
              viewAllLink={`/${type}`}
            />
          </div>
        )}
      </main>
    </div>
  );
}
