"use client";

import { useEffect, useState, use } from "react";
import { Header } from "@/components/header";
import { NavigationMenu } from "@/components/navigation-menu";
import { SearchOverlay } from "@/components/search-overlay";
import { ContentCard } from "@/components/content-card";
import { collection, query, where, orderBy, getDocs } from "firebase/firestore";
import { db } from "@/lib/firebase";

export default function ListingPage({
  params,
}: {
  params: Promise<{ type: string }>;
}) {
  const { type } = use(params);
  
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const titleMap: Record<string, string> = {
    movie: "فیلمەکان",
    series: "زنجیرەکان",
    anime: "ئەنیمەکان",
  };

  const title = titleMap[type] || "لیست";

  useEffect(() => {
    async function fetchContent() {
      try {
        const q = query(
          collection(db, "content"),
          where("type", "==", type),
          orderBy("createdAt", "desc")
        );
        const snapshot = await getDocs(q);
        setItems(snapshot.docs.map(d => ({ id: d.id, ...d.data(), image: d.data().poster })));
      } catch (error) {
        console.error("Error fetching content:", error);
      } finally {
        setLoading(false);
      }
    }

    fetchContent();
  }, [type]);

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <Header />
      <NavigationMenu />
      <SearchOverlay />

      <main className="flex-1 container mx-auto px-4 py-8 md:py-12">
        <h1 className="text-3xl md:text-5xl font-bold mb-8 text-center">{title}</h1>
        
        {loading ? (
          <div className="flex justify-center items-center py-20">
            <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
          </div>
        ) : items.length === 0 ? (
          <div className="text-center text-muted-foreground py-20">
            هیچ ناوەڕۆکێک نەدۆزرایەوە.
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">
            {items.map((item) => (
              <div key={item.id} className="relative group">
                <ContentCard
                  id={item.id}
                  title={item.title}
                  image={item.image}
                  views={item.views ? `${item.views}` : "0"}
                  tags={item.tags || []}
                  type={type as any}
                />
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}

