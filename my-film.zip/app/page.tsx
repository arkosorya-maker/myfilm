"use client";

import { useEffect, useState } from "react";
import { Header } from "@/components/header";
import { NavigationMenu } from "@/components/navigation-menu";
import { SearchOverlay } from "@/components/search-overlay";
import { FeaturedSlider } from "@/components/featured-slider";
import { ContentSection } from "@/components/content-section";
import { collection, query, where, orderBy, limit, getDocs } from "firebase/firestore";
import { db } from "@/lib/firebase";

export default function Home() {
  const [movies, setMovies] = useState<any[]>([]);
  const [series, setSeries] = useState<any[]>([]);
  const [anime, setAnime] = useState<any[]>([]);
  const [channels, setChannels] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchAllContent() {
      try {
        const contentRef = collection(db, "content");
        
        // Fetch Movies
        const qMovies = query(contentRef, where("type", "==", "movie"), orderBy("createdAt", "desc"), limit(6));
        const snapMovies = await getDocs(qMovies);
        setMovies(snapMovies.docs.map(d => ({ id: d.id, ...d.data(), image: d.data().poster })));

        // Fetch Series
        const qSeries = query(contentRef, where("type", "==", "series"), orderBy("createdAt", "desc"), limit(6));
        const snapSeries = await getDocs(qSeries);
        setSeries(snapSeries.docs.map(d => ({ id: d.id, ...d.data(), image: d.data().poster })));

        // Fetch Anime
        const qAnime = query(contentRef, where("type", "==", "anime"), orderBy("createdAt", "desc"), limit(6));
        const snapAnime = await getDocs(qAnime);
        setAnime(snapAnime.docs.map(d => ({ id: d.id, ...d.data(), image: d.data().poster })));

        // Fetch Channels
        const qChannels = query(contentRef, where("type", "==", "channel"), orderBy("createdAt", "desc"), limit(6));
        const snapChannels = await getDocs(qChannels);
        setChannels(snapChannels.docs.map(d => ({ id: d.id, ...d.data(), image: d.data().poster })));

      } catch (error) {
        console.error("Error fetching content:", error);
      } finally {
        setLoading(false);
      }
    }

    fetchAllContent();
  }, []);

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <NavigationMenu />
      <SearchOverlay />

      <main className="flex-1 pb-16">
        {/* Hero Section */}
        <section className="bg-[#0A0C12] border-b border-[#2A2D3A]">
          <div className="container mx-auto px-4 py-8">
            <FeaturedSlider />
          </div>
        </section>

        {loading ? (
          <div className="flex justify-center items-center py-20">
            <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
          </div>
        ) : (
          <>
            <ContentSection
              title="نوێترین فیلمەکان"
              items={movies}
              type="movie"
              viewAllLink="/movie"
            />
            <ContentSection
              title="نوێترین زنجیرەکان"
              items={series}
              type="series"
              viewAllLink="/series"
            />
            <ContentSection
              title="نوێترین ئەنیمەکان"
              items={anime}
              type="anime"
              viewAllLink="/anime"
            />
            <ContentSection
              title="کەناڵەکان"
              items={channels}
              type="channel"
              viewAllLink="/channels"
            />
          </>
        )}
      </main>
    </div>
  );
}
